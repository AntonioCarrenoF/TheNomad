var class_disparar =
[
    [ "DispararArma", "de/d4b/class_disparar.html#a81770fb0497ae820d85d240e516aec32", null ],
    [ "distanciaDisparo", "de/d4b/class_disparar.html#a45de14a4d5d2d530254e336a43d031ef", null ],
    [ "prefabBala", "de/d4b/class_disparar.html#abfe3d96958254876ae21d549bf0d8f88", null ],
    [ "velocidadDisparo", "de/d4b/class_disparar.html#ab488c0a7d4307f8fa22b716b3a897afd", null ]
];