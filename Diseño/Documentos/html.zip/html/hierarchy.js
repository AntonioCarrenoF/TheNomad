var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "AdministradorVidas", "dd/d77/class_administrador_vidas.html", null ],
      [ "BotonesDialogo", "d1/d4d/class_botones_dialogo.html", null ],
      [ "BotonesFinJuego", "d6/dad/class_botones_fin_juego.html", null ],
      [ "BotonesMenuControles", "d5/ddf/class_botones_menu_controles.html", null ],
      [ "BotonesMenuPrincipal", "dd/db1/class_botones_menu_principal.html", null ],
      [ "BotonesPausa", "d5/d0d/class_botones_pausa.html", null ],
      [ "BotonesUI", "d2/d31/class_botones_u_i.html", null ],
      [ "ColisionBala", "dd/da2/class_colision_bala.html", null ],
      [ "ColisionBalaNPC", "dc/d8c/class_colision_bala_n_p_c.html", null ],
      [ "DialogoNPC", "d2/d18/class_dialogo_n_p_c.html", null ],
      [ "Disparar", "de/d4b/class_disparar.html", [
        [ "DispararNPC", "da/d78/class_disparar_n_p_c.html", null ]
      ] ],
      [ "InteraccionNPC", "dc/d64/class_interaccion_n_p_c.html", null ],
      [ "MenuFinJuego", "da/dd2/class_menu_fin_juego.html", null ],
      [ "MenuInicial", "da/d88/class_menu_inicial.html", null ],
      [ "MenuPausa", "d0/d9b/class_menu_pausa.html", null ],
      [ "MisionPrimera", "da/d9d/class_mision_primera.html", null ],
      [ "RecuperarSalud", "dd/d2c/class_recuperar_salud.html", null ],
      [ "SaludNPC", "d8/d71/class_salud_n_p_c.html", null ],
      [ "TiempoParado", "d7/df2/class_tiempo_parado.html", null ]
    ] ]
];