var searchData=
[
  ['administradorvidas_0',['AdministradorVidas',['../dd/d77/class_administrador_vidas.html',1,'']]],
  ['administradorvidas_2ecs_1',['AdministradorVidas.cs',['../d1/d54/_administrador_vidas_8cs.html',1,'']]]
];
