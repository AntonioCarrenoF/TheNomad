var searchData=
[
  ['salirdeljuego_0',['SalirDelJuego',['../d0/d9b/class_menu_pausa.html#a6ff35bc892b5e1087d7341d2a3fbc803',1,'MenuPausa']]],
  ['start_1',['Start',['../dd/d77/class_administrador_vidas.html#ad0f67f59633b5dc5d239023d96ae1176',1,'AdministradorVidas']]]
];
