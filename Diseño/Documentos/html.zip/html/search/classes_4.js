var searchData=
[
  ['interaccionnpc_0',['InteraccionNPC',['../dc/d64/class_interaccion_n_p_c.html',1,'']]]
];
