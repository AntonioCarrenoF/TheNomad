var searchData=
[
  ['perdervida_0',['PerderVida',['../dd/d77/class_administrador_vidas.html#ac9e4de0ea0720d5a0b32a6372120ee7b',1,'AdministradorVidas']]]
];
