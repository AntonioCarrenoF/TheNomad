var searchData=
[
  ['disparararma_0',['DispararArma',['../de/d4b/class_disparar.html#a81770fb0497ae820d85d240e516aec32',1,'Disparar.DispararArma()'],['../da/d78/class_disparar_n_p_c.html#a0dc8f85886e0dffe30f2de6078cb255a',1,'DispararNPC.DispararArma()']]]
];
