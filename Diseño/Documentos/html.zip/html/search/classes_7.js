var searchData=
[
  ['tiempoparado_0',['TiempoParado',['../d7/df2/class_tiempo_parado.html',1,'']]]
];
