var searchData=
[
  ['particulasexplosion_0',['particulasExplosion',['../dc/d8c/class_colision_bala_n_p_c.html#a8a36cf5c6d7df3000b3d62637431a8fe',1,'ColisionBalaNPC']]],
  ['prefabbala_1',['prefabBala',['../de/d4b/class_disparar.html#abfe3d96958254876ae21d549bf0d8f88',1,'Disparar']]],
  ['prefabvidas_2',['prefabVidas',['../dd/d77/class_administrador_vidas.html#a27bed5550c74c8c05696ea45f6c0478f',1,'AdministradorVidas']]],
  ['puntodisparo_3',['puntoDisparo',['../da/d78/class_disparar_n_p_c.html#aa3486b07d10344fed05eb850012d79a5',1,'DispararNPC']]]
];
