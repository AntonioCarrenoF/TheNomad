var searchData=
[
  ['ocultarmenupausa_0',['OcultarMenuPausa',['../d0/d9b/class_menu_pausa.html#a5e55c4f7bbe19b0c88ac12894d2d7761',1,'MenuPausa']]],
  ['oncollisionenter_1',['OnCollisionEnter',['../dd/da2/class_colision_bala.html#ad2fc1c9b8c39e79a08017d6e9c2bf1e2',1,'ColisionBala']]],
  ['opcion1_2',['Opcion1',['../d2/d18/class_dialogo_n_p_c.html#a325456a6ca7e57c1630e8ecb9022de29',1,'DialogoNPC']]],
  ['opcion2_3',['Opcion2',['../d2/d18/class_dialogo_n_p_c.html#a16622314ddb89614e3afe7b7ee4ee633',1,'DialogoNPC']]]
];
