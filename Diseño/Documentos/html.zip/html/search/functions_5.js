var searchData=
[
  ['mostrarcontroles_0',['MostrarControles',['../da/d88/class_menu_inicial.html#aac31b71d980bbc67361a5749e8c19686',1,'MenuInicial']]],
  ['mostrarmenuinicial_1',['MostrarMenuInicial',['../da/d88/class_menu_inicial.html#a8c6b4e00ead49c3d1203c4dce6b97f11',1,'MenuInicial']]],
  ['mostrarmenupausa_2',['MostrarMenuPausa',['../d0/d9b/class_menu_pausa.html#a2cf1ddf8c132ca3f363021891e6e6d0d',1,'MenuPausa']]],
  ['muertenpc_3',['MuerteNPC',['../d8/d71/class_salud_n_p_c.html#a9c0f972d809cbb3fc87e17c0a27cc91c',1,'SaludNPC']]]
];
