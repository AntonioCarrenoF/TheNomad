var searchData=
[
  ['ganarvida_0',['GanarVida',['../dd/d77/class_administrador_vidas.html#ad1bbccdde09b1be03846db37e6d78b99',1,'AdministradorVidas']]]
];
