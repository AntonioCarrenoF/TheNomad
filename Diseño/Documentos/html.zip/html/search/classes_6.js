var searchData=
[
  ['saludnpc_0',['SaludNPC',['../d8/d71/class_salud_n_p_c.html',1,'']]]
];
