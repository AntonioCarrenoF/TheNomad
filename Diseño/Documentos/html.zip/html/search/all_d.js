var searchData=
[
  ['tecla1_0',['tecla1',['../d1/d4d/class_botones_dialogo.html#a325a36b4c9dce605713409f842ea45f9',1,'BotonesDialogo.tecla1'],['../d6/dad/class_botones_fin_juego.html#adf8e6e4f0ee0aa460360ac38bfb9ad9a',1,'BotonesFinJuego.tecla1'],['../d5/ddf/class_botones_menu_controles.html#a389962d9b25459fa1f2f45cc5f7fb760',1,'BotonesMenuControles.tecla1'],['../dd/db1/class_botones_menu_principal.html#a2421b9cadef8fc390a96c59617db7d87',1,'BotonesMenuPrincipal.tecla1'],['../d5/d0d/class_botones_pausa.html#a965f93402e4923443c882ec5edd875d1',1,'BotonesPausa.tecla1'],['../d2/d31/class_botones_u_i.html#ac64bca68ddbe21280e68f50d1c51b4a5',1,'BotonesUI.tecla1']]],
  ['tecla2_1',['tecla2',['../d1/d4d/class_botones_dialogo.html#a415a0bafbf372e6de9014a49d786ba6b',1,'BotonesDialogo.tecla2'],['../d6/dad/class_botones_fin_juego.html#ae417dfdff3c2d840ee11d60f18da0aef',1,'BotonesFinJuego.tecla2'],['../dd/db1/class_botones_menu_principal.html#a547fbeddffaffb8ff440eb2387282b6e',1,'BotonesMenuPrincipal.tecla2'],['../d5/d0d/class_botones_pausa.html#af95cd0f8b4623d59c94f97a6066ca5f5',1,'BotonesPausa.tecla2']]],
  ['tecla3_2',['tecla3',['../dd/db1/class_botones_menu_principal.html#a9e9528cb0543ac06d6ed9edf7355d545',1,'BotonesMenuPrincipal.tecla3'],['../d5/d0d/class_botones_pausa.html#a2b1ce762b7399259d27ecd09e71ca7a2',1,'BotonesPausa.tecla3']]],
  ['textodialogo_3',['textoDialogo',['../d2/d18/class_dialogo_n_p_c.html#aefb10c7b0707067aee53c6cff603eca4',1,'DialogoNPC']]],
  ['textovidas_4',['textoVidas',['../dd/d77/class_administrador_vidas.html#a0dfda4db1c4d110b9f23475c0b11411d',1,'AdministradorVidas']]],
  ['tiempoparado_5',['TiempoParado',['../d7/df2/class_tiempo_parado.html',1,'']]]
];
