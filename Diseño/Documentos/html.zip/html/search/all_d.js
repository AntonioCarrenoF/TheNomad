var searchData=
[
  ['velocidaddisparo_0',['velocidadDisparo',['../de/d4b/class_disparar.html#ab488c0a7d4307f8fa22b716b3a897afd',1,'Disparar']]],
  ['vidasiniciales_1',['vidasIniciales',['../dd/d77/class_administrador_vidas.html#a7c2de5787eb07e2616df2d561b3483ac',1,'AdministradorVidas']]]
];
