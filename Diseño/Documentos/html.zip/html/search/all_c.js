var searchData=
[
  ['salirdeljuego_0',['SalirDelJuego',['../d0/d9b/class_menu_pausa.html#a6ff35bc892b5e1087d7341d2a3fbc803',1,'MenuPausa']]],
  ['saludactual_1',['saludActual',['../d8/d71/class_salud_n_p_c.html#aee7dd1a826f07a9015fa1262e5fb21ff',1,'SaludNPC']]],
  ['saludmaxima_2',['saludMaxima',['../d8/d71/class_salud_n_p_c.html#a91f79f62181b03c72aa79b921b3a8b68',1,'SaludNPC']]],
  ['saludnpc_3',['SaludNPC',['../d8/d71/class_salud_n_p_c.html',1,'']]],
  ['saludnpc_2ecs_4',['SaludNPC.cs',['../d5/d9e/_salud_n_p_c_8cs.html',1,'']]],
  ['saludrecuperada_5',['saludRecuperada',['../dd/d2c/class_recuperar_salud.html#a50c8c52d8c5ad2d7b3f02653a29b23d5',1,'RecuperarSalud']]],
  ['start_6',['Start',['../dd/d77/class_administrador_vidas.html#ad0f67f59633b5dc5d239023d96ae1176',1,'AdministradorVidas']]]
];
