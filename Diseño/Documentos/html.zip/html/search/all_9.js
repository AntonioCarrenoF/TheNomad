var searchData=
[
  ['parartiempo_2ecs_0',['PararTiempo.cs',['../d8/d26/_parar_tiempo_8cs.html',1,'']]],
  ['perdervida_1',['PerderVida',['../dd/d77/class_administrador_vidas.html#ac9e4de0ea0720d5a0b32a6372120ee7b',1,'AdministradorVidas']]],
  ['prefabbala_2',['prefabBala',['../de/d4b/class_disparar.html#abfe3d96958254876ae21d549bf0d8f88',1,'Disparar']]],
  ['prefabvidas_3',['prefabVidas',['../dd/d77/class_administrador_vidas.html#a27bed5550c74c8c05696ea45f6c0478f',1,'AdministradorVidas']]],
  ['puntodisparo_4',['puntoDisparo',['../da/d78/class_disparar_n_p_c.html#aa3486b07d10344fed05eb850012d79a5',1,'DispararNPC']]]
];
