var searchData=
[
  ['objetorecolectar_0',['objetoRecolectar',['../da/d9d/class_mision_primera.html#a083924ab669009bca260cb15b946282c',1,'MisionPrimera']]],
  ['objetosvida_1',['objetosVida',['../dd/d77/class_administrador_vidas.html#a071a345fb750133e7ce146e17a283134',1,'AdministradorVidas']]],
  ['ocultarmenupausa_2',['OcultarMenuPausa',['../d0/d9b/class_menu_pausa.html#a5e55c4f7bbe19b0c88ac12894d2d7761',1,'MenuPausa']]],
  ['oncollisionenter_3',['OnCollisionEnter',['../dd/da2/class_colision_bala.html#ad2fc1c9b8c39e79a08017d6e9c2bf1e2',1,'ColisionBala']]],
  ['opcion1_4',['Opcion1',['../d2/d18/class_dialogo_n_p_c.html#a325456a6ca7e57c1630e8ecb9022de29',1,'DialogoNPC']]],
  ['opcion1_5',['opcion1',['../d2/d18/class_dialogo_n_p_c.html#a38dbe7cf292e4148d1379fd5c7e4ceed',1,'DialogoNPC']]],
  ['opcion1texto_6',['opcion1Texto',['../d2/d18/class_dialogo_n_p_c.html#a4bdb7a2d257208cf914e72882b4598db',1,'DialogoNPC']]],
  ['opcion2_7',['Opcion2',['../d2/d18/class_dialogo_n_p_c.html#a16622314ddb89614e3afe7b7ee4ee633',1,'DialogoNPC']]],
  ['opcion2_8',['opcion2',['../d2/d18/class_dialogo_n_p_c.html#ac7cabe7a91dc819c54dcb4d008c65868',1,'DialogoNPC']]],
  ['opcion2texto_9',['opcion2Texto',['../d2/d18/class_dialogo_n_p_c.html#ae8e7e52f96e4d591b0cbbf846b0a6269',1,'DialogoNPC']]]
];
