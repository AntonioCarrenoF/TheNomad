var searchData=
[
  ['camara_0',['camara',['../d7/df2/class_tiempo_parado.html#a1aa59f6caa1303d0692738750f7294c3',1,'TiempoParado']]],
  ['canvasvidas_1',['canvasVidas',['../dd/d77/class_administrador_vidas.html#a0a8b1c768181b6d379097236e5b4f508',1,'AdministradorVidas']]]
];
