var searchData=
[
  ['canvasvidas_0',['canvasVidas',['../dd/d77/class_administrador_vidas.html#a0a8b1c768181b6d379097236e5b4f508',1,'AdministradorVidas']]]
];
