var searchData=
[
  ['parartiempo_2ecs_0',['PararTiempo.cs',['../d8/d26/_parar_tiempo_8cs.html',1,'']]],
  ['particulasexplosion_1',['particulasExplosion',['../dc/d8c/class_colision_bala_n_p_c.html#a8a36cf5c6d7df3000b3d62637431a8fe',1,'ColisionBalaNPC']]],
  ['perdervida_2',['PerderVida',['../dd/d77/class_administrador_vidas.html#ac9e4de0ea0720d5a0b32a6372120ee7b',1,'AdministradorVidas']]],
  ['prefabbala_3',['prefabBala',['../de/d4b/class_disparar.html#abfe3d96958254876ae21d549bf0d8f88',1,'Disparar']]],
  ['prefabvidas_4',['prefabVidas',['../dd/d77/class_administrador_vidas.html#a27bed5550c74c8c05696ea45f6c0478f',1,'AdministradorVidas']]],
  ['puntodisparo_5',['puntoDisparo',['../da/d78/class_disparar_n_p_c.html#aa3486b07d10344fed05eb850012d79a5',1,'DispararNPC']]]
];
