var searchData=
[
  ['dialogonpc_0',['DialogoNPC',['../d2/d18/class_dialogo_n_p_c.html',1,'']]],
  ['disparar_1',['Disparar',['../de/d4b/class_disparar.html',1,'']]],
  ['dispararnpc_2',['DispararNPC',['../da/d78/class_disparar_n_p_c.html',1,'']]]
];
