var searchData=
[
  ['recibirdano_0',['RecibirDano',['../d8/d71/class_salud_n_p_c.html#aca31047c026db2f8afc0d3832622a58c',1,'SaludNPC']]],
  ['regresarapantallaprincipal_1',['RegresarAPantallaPrincipal',['../d0/d9b/class_menu_pausa.html#ab3053f1570145d4aa2260faf6fc8d143',1,'MenuPausa']]],
  ['reintentarnivel_2',['ReintentarNivel',['../da/dd2/class_menu_fin_juego.html#a27e58f0ad6342e6c17a6e05b625f07cc',1,'MenuFinJuego']]]
];
