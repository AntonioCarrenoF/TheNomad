var searchData=
[
  ['botonamistoso_0',['botonAmistoso',['../d1/d4d/class_botones_dialogo.html#aee48c6df0ec7940c8e793c09ae037f5b',1,'BotonesDialogo']]],
  ['botoncontroles_1',['botonControles',['../dd/db1/class_botones_menu_principal.html#a23a7ea2746b04576c9e7ab8248528452',1,'BotonesMenuPrincipal']]],
  ['botondesagradable_2',['botonDesagradable',['../d1/d4d/class_botones_dialogo.html#a3a0c630b527fbfdf5f1fa39b787d01ee',1,'BotonesDialogo']]],
  ['botoniniciar_3',['botonIniciar',['../dd/db1/class_botones_menu_principal.html#a827338e43ff3eb160dd58dc7e3e872ce',1,'BotonesMenuPrincipal']]],
  ['botonmenu_4',['botonMenu',['../d6/dad/class_botones_fin_juego.html#ad3f0e7f5e8c89e7a54144c8f7c25e174',1,'BotonesFinJuego.botonMenu'],['../d5/d0d/class_botones_pausa.html#a38387351491a17f1c8a0e055a1743e3e',1,'BotonesPausa.botonMenu']]],
  ['botonpausa_5',['botonPausa',['../d2/d31/class_botones_u_i.html#ae3e57cff3e4d4031677ba7c427736221',1,'BotonesUI']]],
  ['botonreanudar_6',['botonReanudar',['../d5/d0d/class_botones_pausa.html#a37695df83ab0bc40cb344d4885ff122b',1,'BotonesPausa']]],
  ['botonregresar_7',['botonRegresar',['../d5/ddf/class_botones_menu_controles.html#a188d52c3b129ba1d1bf012e0f5ce6ea6',1,'BotonesMenuControles']]],
  ['botonreiniciar_8',['botonReiniciar',['../d6/dad/class_botones_fin_juego.html#a6f80b736e7378946b302ac0e1a8a0cc8',1,'BotonesFinJuego']]],
  ['botonsalir_9',['botonSalir',['../dd/db1/class_botones_menu_principal.html#a0dc42a6f5add55956a5c532f4e26d47b',1,'BotonesMenuPrincipal.botonSalir'],['../d5/d0d/class_botones_pausa.html#a86f5726b445c84c0c87f3df8dc446dd0',1,'BotonesPausa.botonSalir']]]
];
