var searchData=
[
  ['iniciarjuego_0',['IniciarJuego',['../da/d88/class_menu_inicial.html#acb9a11f149e35503d93f52ba32deacec',1,'MenuInicial']]],
  ['interaccionnpc_1',['InteraccionNPC',['../dc/d64/class_interaccion_n_p_c.html',1,'']]],
  ['interaccionnpc_2ecs_2',['InteraccionNPC.cs',['../d5/d45/_interaccion_n_p_c_8cs.html',1,'']]]
];
