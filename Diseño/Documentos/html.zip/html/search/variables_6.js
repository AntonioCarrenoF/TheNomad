var searchData=
[
  ['prefabbala_0',['prefabBala',['../de/d4b/class_disparar.html#abfe3d96958254876ae21d549bf0d8f88',1,'Disparar']]],
  ['prefabvidas_1',['prefabVidas',['../dd/d77/class_administrador_vidas.html#a27bed5550c74c8c05696ea45f6c0478f',1,'AdministradorVidas']]],
  ['puntodisparo_2',['puntoDisparo',['../da/d78/class_disparar_n_p_c.html#aa3486b07d10344fed05eb850012d79a5',1,'DispararNPC']]]
];
