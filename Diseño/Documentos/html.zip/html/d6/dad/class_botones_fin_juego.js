var class_botones_fin_juego =
[
    [ "botonMenu", "d6/dad/class_botones_fin_juego.html#ad3f0e7f5e8c89e7a54144c8f7c25e174", null ],
    [ "botonReiniciar", "d6/dad/class_botones_fin_juego.html#a6f80b736e7378946b302ac0e1a8a0cc8", null ],
    [ "tecla1", "d6/dad/class_botones_fin_juego.html#adf8e6e4f0ee0aa460360ac38bfb9ad9a", null ],
    [ "tecla2", "d6/dad/class_botones_fin_juego.html#ae417dfdff3c2d840ee11d60f18da0aef", null ]
];