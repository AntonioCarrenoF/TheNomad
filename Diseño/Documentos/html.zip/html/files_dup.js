var files_dup =
[
    [ "AdministradorVidas.cs", "d1/d54/_administrador_vidas_8cs.html", "d1/d54/_administrador_vidas_8cs" ],
    [ "BotonesDialogo.cs", "df/de3/_botones_dialogo_8cs.html", "df/de3/_botones_dialogo_8cs" ],
    [ "BotonesFinJuego.cs", "d4/d0a/_botones_fin_juego_8cs.html", "d4/d0a/_botones_fin_juego_8cs" ],
    [ "BotonesMenuControles.cs", "d2/dcc/_botones_menu_controles_8cs.html", "d2/dcc/_botones_menu_controles_8cs" ],
    [ "BotonesMenuPrincipal.cs", "df/d08/_botones_menu_principal_8cs.html", "df/d08/_botones_menu_principal_8cs" ],
    [ "BotonesPausa.cs", "d1/d58/_botones_pausa_8cs.html", "d1/d58/_botones_pausa_8cs" ],
    [ "BotonesUI.cs", "d5/d04/_botones_u_i_8cs.html", "d5/d04/_botones_u_i_8cs" ],
    [ "ColisionBala.cs", "d6/d5e/_colision_bala_8cs.html", "d6/d5e/_colision_bala_8cs" ],
    [ "ColisionBalaNPC.cs", "d8/dd5/_colision_bala_n_p_c_8cs.html", "d8/dd5/_colision_bala_n_p_c_8cs" ],
    [ "DialogoNPC.cs", "db/d13/_dialogo_n_p_c_8cs.html", "db/d13/_dialogo_n_p_c_8cs" ],
    [ "Disparar.cs", "d2/df3/_disparar_8cs.html", "d2/df3/_disparar_8cs" ],
    [ "DispararNPC.cs", "d3/dfa/_disparar_n_p_c_8cs.html", "d3/dfa/_disparar_n_p_c_8cs" ],
    [ "InteraccionNPC.cs", "d5/d45/_interaccion_n_p_c_8cs.html", "d5/d45/_interaccion_n_p_c_8cs" ],
    [ "MenuFinJuego.cs", "db/d96/_menu_fin_juego_8cs.html", "db/d96/_menu_fin_juego_8cs" ],
    [ "MenuInicial.cs", "db/d76/_menu_inicial_8cs.html", "db/d76/_menu_inicial_8cs" ],
    [ "MenuPausa.cs", "d6/d15/_menu_pausa_8cs.html", "d6/d15/_menu_pausa_8cs" ],
    [ "PararTiempo.cs", "d8/d26/_parar_tiempo_8cs.html", "d8/d26/_parar_tiempo_8cs" ],
    [ "SaludNPC.cs", "d5/d9e/_salud_n_p_c_8cs.html", "d5/d9e/_salud_n_p_c_8cs" ]
];