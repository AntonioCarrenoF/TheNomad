var class_menu_inicial =
[
    [ "FinalizarJuego", "da/d88/class_menu_inicial.html#a7486c9edc2ebf68a4a35d1db235bf3cb", null ],
    [ "IniciarJuego", "da/d88/class_menu_inicial.html#acb9a11f149e35503d93f52ba32deacec", null ],
    [ "MostrarControles", "da/d88/class_menu_inicial.html#aac31b71d980bbc67361a5749e8c19686", null ],
    [ "MostrarMenuInicial", "da/d88/class_menu_inicial.html#a8c6b4e00ead49c3d1203c4dce6b97f11", null ],
    [ "MenuControles", "da/d88/class_menu_inicial.html#afac18708b5c8aadd93316f3b311cdca7", null ],
    [ "MenuPrincipal", "da/d88/class_menu_inicial.html#a37ad8eca5a9f137008f090bb86082175", null ]
];