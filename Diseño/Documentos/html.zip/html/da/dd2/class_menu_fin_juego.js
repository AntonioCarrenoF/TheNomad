var class_menu_fin_juego =
[
    [ "CargarMenuPrincipal", "da/dd2/class_menu_fin_juego.html#aa55e60c9e9137036831e1b5b84de1d76", null ],
    [ "ReintentarNivel", "da/dd2/class_menu_fin_juego.html#a27e58f0ad6342e6c17a6e05b625f07cc", null ]
];