var class_mision_primera =
[
    [ "menuGanado", "da/d9d/class_mision_primera.html#ab97cbbfb62dd9fdd0bc15fbf5a93eebf", null ],
    [ "objetoRecolectar", "da/d9d/class_mision_primera.html#a083924ab669009bca260cb15b946282c", null ]
];