var class_botones_u_i =
[
    [ "botonPausa", "d2/d31/class_botones_u_i.html#ae3e57cff3e4d4031677ba7c427736221", null ],
    [ "tecla1", "d2/d31/class_botones_u_i.html#ac64bca68ddbe21280e68f50d1c51b4a5", null ]
];