var class_dialogo_n_p_c =
[
    [ "Opcion1", "d2/d18/class_dialogo_n_p_c.html#a325456a6ca7e57c1630e8ecb9022de29", null ],
    [ "Opcion2", "d2/d18/class_dialogo_n_p_c.html#a16622314ddb89614e3afe7b7ee4ee633", null ],
    [ "dialogoInicial", "d2/d18/class_dialogo_n_p_c.html#a7f43476d99f37bf9621608fcad8bf143", null ],
    [ "dialogoOpcion1", "d2/d18/class_dialogo_n_p_c.html#acd241ab9aa2e8336d374491c65202f6a", null ],
    [ "dialogoOpcion2", "d2/d18/class_dialogo_n_p_c.html#a1c1220118cf5e3a9cc94d8e93632877c", null ],
    [ "opcion1", "d2/d18/class_dialogo_n_p_c.html#a38dbe7cf292e4148d1379fd5c7e4ceed", null ],
    [ "opcion1Texto", "d2/d18/class_dialogo_n_p_c.html#a4bdb7a2d257208cf914e72882b4598db", null ],
    [ "opcion2", "d2/d18/class_dialogo_n_p_c.html#ac7cabe7a91dc819c54dcb4d008c65868", null ],
    [ "opcion2Texto", "d2/d18/class_dialogo_n_p_c.html#ae8e7e52f96e4d591b0cbbf846b0a6269", null ],
    [ "textoDialogo", "d2/d18/class_dialogo_n_p_c.html#aefb10c7b0707067aee53c6cff603eca4", null ]
];