var class_recuperar_salud =
[
    [ "administradorVidas", "dd/d2c/class_recuperar_salud.html#a184af95b717d0c039fd2bee067132c76", null ],
    [ "saludRecuperada", "dd/d2c/class_recuperar_salud.html#a50c8c52d8c5ad2d7b3f02653a29b23d5", null ]
];