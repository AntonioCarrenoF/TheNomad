var class_botones_menu_principal =
[
    [ "botonControles", "dd/db1/class_botones_menu_principal.html#a23a7ea2746b04576c9e7ab8248528452", null ],
    [ "botonIniciar", "dd/db1/class_botones_menu_principal.html#a827338e43ff3eb160dd58dc7e3e872ce", null ],
    [ "botonSalir", "dd/db1/class_botones_menu_principal.html#a0dc42a6f5add55956a5c532f4e26d47b", null ],
    [ "tecla1", "dd/db1/class_botones_menu_principal.html#a2421b9cadef8fc390a96c59617db7d87", null ],
    [ "tecla2", "dd/db1/class_botones_menu_principal.html#a547fbeddffaffb8ff440eb2387282b6e", null ],
    [ "tecla3", "dd/db1/class_botones_menu_principal.html#a9e9528cb0543ac06d6ed9edf7355d545", null ]
];