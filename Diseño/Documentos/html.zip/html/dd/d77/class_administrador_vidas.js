var class_administrador_vidas =
[
    [ "PerderVida", "dd/d77/class_administrador_vidas.html#ac9e4de0ea0720d5a0b32a6372120ee7b", null ],
    [ "Start", "dd/d77/class_administrador_vidas.html#ad0f67f59633b5dc5d239023d96ae1176", null ],
    [ "canvasVidas", "dd/d77/class_administrador_vidas.html#a0a8b1c768181b6d379097236e5b4f508", null ],
    [ "menuFinJuego", "dd/d77/class_administrador_vidas.html#aad6cda9a277b00304262756fee190dec", null ],
    [ "objetosVida", "dd/d77/class_administrador_vidas.html#a071a345fb750133e7ce146e17a283134", null ],
    [ "prefabVidas", "dd/d77/class_administrador_vidas.html#a27bed5550c74c8c05696ea45f6c0478f", null ],
    [ "textoVidas", "dd/d77/class_administrador_vidas.html#a0dfda4db1c4d110b9f23475c0b11411d", null ],
    [ "vidasIniciales", "dd/d77/class_administrador_vidas.html#a7c2de5787eb07e2616df2d561b3483ac", null ]
];