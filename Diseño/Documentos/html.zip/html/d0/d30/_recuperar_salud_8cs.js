var _recuperar_salud_8cs =
[
    [ "RecuperarSalud", "dd/d2c/class_recuperar_salud.html", "dd/d2c/class_recuperar_salud" ]
];