var class_menu_pausa =
[
    [ "MostrarMenuPausa", "d0/d9b/class_menu_pausa.html#a2cf1ddf8c132ca3f363021891e6e6d0d", null ],
    [ "OcultarMenuPausa", "d0/d9b/class_menu_pausa.html#a5e55c4f7bbe19b0c88ac12894d2d7761", null ],
    [ "RegresarAPantallaPrincipal", "d0/d9b/class_menu_pausa.html#ab3053f1570145d4aa2260faf6fc8d143", null ],
    [ "SalirDelJuego", "d0/d9b/class_menu_pausa.html#a6ff35bc892b5e1087d7341d2a3fbc803", null ],
    [ "menuPausa", "d0/d9b/class_menu_pausa.html#a9238513bfce028b168651ab8449a12e7", null ]
];