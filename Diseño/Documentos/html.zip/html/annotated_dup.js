var annotated_dup =
[
    [ "AdministradorVidas", "dd/d77/class_administrador_vidas.html", "dd/d77/class_administrador_vidas" ],
    [ "BotonesDialogo", "d1/d4d/class_botones_dialogo.html", "d1/d4d/class_botones_dialogo" ],
    [ "BotonesFinJuego", "d6/dad/class_botones_fin_juego.html", "d6/dad/class_botones_fin_juego" ],
    [ "BotonesMenuControles", "d5/ddf/class_botones_menu_controles.html", "d5/ddf/class_botones_menu_controles" ],
    [ "BotonesMenuPrincipal", "dd/db1/class_botones_menu_principal.html", "dd/db1/class_botones_menu_principal" ],
    [ "BotonesPausa", "d5/d0d/class_botones_pausa.html", "d5/d0d/class_botones_pausa" ],
    [ "BotonesUI", "d2/d31/class_botones_u_i.html", "d2/d31/class_botones_u_i" ],
    [ "ColisionBala", "dd/da2/class_colision_bala.html", "dd/da2/class_colision_bala" ],
    [ "ColisionBalaNPC", "dc/d8c/class_colision_bala_n_p_c.html", "dc/d8c/class_colision_bala_n_p_c" ],
    [ "DialogoNPC", "d2/d18/class_dialogo_n_p_c.html", "d2/d18/class_dialogo_n_p_c" ],
    [ "Disparar", "de/d4b/class_disparar.html", "de/d4b/class_disparar" ],
    [ "DispararNPC", "da/d78/class_disparar_n_p_c.html", "da/d78/class_disparar_n_p_c" ],
    [ "InteraccionNPC", "dc/d64/class_interaccion_n_p_c.html", "dc/d64/class_interaccion_n_p_c" ],
    [ "MenuFinJuego", "da/dd2/class_menu_fin_juego.html", "da/dd2/class_menu_fin_juego" ],
    [ "MenuInicial", "da/d88/class_menu_inicial.html", "da/d88/class_menu_inicial" ],
    [ "MenuPausa", "d0/d9b/class_menu_pausa.html", "d0/d9b/class_menu_pausa" ],
    [ "SaludNPC", "d8/d71/class_salud_n_p_c.html", "d8/d71/class_salud_n_p_c" ],
    [ "TiempoParado", "d7/df2/class_tiempo_parado.html", null ]
];