var class_salud_n_p_c =
[
    [ "MuerteNPC", "d8/d71/class_salud_n_p_c.html#a9c0f972d809cbb3fc87e17c0a27cc91c", null ],
    [ "RecibirDano", "d8/d71/class_salud_n_p_c.html#aca31047c026db2f8afc0d3832622a58c", null ],
    [ "saludActual", "d8/d71/class_salud_n_p_c.html#aee7dd1a826f07a9015fa1262e5fb21ff", null ],
    [ "saludMaxima", "d8/d71/class_salud_n_p_c.html#a91f79f62181b03c72aa79b921b3a8b68", null ]
];