var _parar_tiempo_8cs =
[
    [ "TiempoParado", "d7/df2/class_tiempo_parado.html", "d7/df2/class_tiempo_parado" ]
];