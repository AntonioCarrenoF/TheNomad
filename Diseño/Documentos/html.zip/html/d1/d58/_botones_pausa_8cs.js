var _botones_pausa_8cs =
[
    [ "BotonesPausa", "d5/d0d/class_botones_pausa.html", "d5/d0d/class_botones_pausa" ]
];