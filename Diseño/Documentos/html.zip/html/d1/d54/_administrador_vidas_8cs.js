var _administrador_vidas_8cs =
[
    [ "AdministradorVidas", "dd/d77/class_administrador_vidas.html", "dd/d77/class_administrador_vidas" ]
];