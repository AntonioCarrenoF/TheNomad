var class_botones_dialogo =
[
    [ "botonAmistoso", "d1/d4d/class_botones_dialogo.html#aee48c6df0ec7940c8e793c09ae037f5b", null ],
    [ "botonDesagradable", "d1/d4d/class_botones_dialogo.html#a3a0c630b527fbfdf5f1fa39b787d01ee", null ],
    [ "tecla1", "d1/d4d/class_botones_dialogo.html#a325a36b4c9dce605713409f842ea45f9", null ],
    [ "tecla2", "d1/d4d/class_botones_dialogo.html#a415a0bafbf372e6de9014a49d786ba6b", null ]
];