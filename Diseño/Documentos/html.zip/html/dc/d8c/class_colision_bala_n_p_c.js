var class_colision_bala_n_p_c =
[
    [ "dano", "dc/d8c/class_colision_bala_n_p_c.html#a1d39cab24abcae60979c7e894bb8e106", null ],
    [ "particulasExplosion", "dc/d8c/class_colision_bala_n_p_c.html#a8a36cf5c6d7df3000b3d62637431a8fe", null ]
];