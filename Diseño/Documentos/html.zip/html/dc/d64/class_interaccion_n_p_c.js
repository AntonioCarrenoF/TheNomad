var class_interaccion_n_p_c =
[
    [ "npc", "dc/d64/class_interaccion_n_p_c.html#a3d58f0faa6ed96d93e1931f5fbeffd73", null ]
];