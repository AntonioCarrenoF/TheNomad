var class_tiempo_parado =
[
    [ "camara", "d7/df2/class_tiempo_parado.html#a1aa59f6caa1303d0692738750f7294c3", null ]
];