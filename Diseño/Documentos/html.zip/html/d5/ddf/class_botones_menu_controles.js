var class_botones_menu_controles =
[
    [ "botonRegresar", "d5/ddf/class_botones_menu_controles.html#a188d52c3b129ba1d1bf012e0f5ce6ea6", null ],
    [ "tecla1", "d5/ddf/class_botones_menu_controles.html#a389962d9b25459fa1f2f45cc5f7fb760", null ]
];