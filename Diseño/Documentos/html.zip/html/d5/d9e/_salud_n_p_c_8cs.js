var _salud_n_p_c_8cs =
[
    [ "SaludNPC", "d8/d71/class_salud_n_p_c.html", "d8/d71/class_salud_n_p_c" ]
];