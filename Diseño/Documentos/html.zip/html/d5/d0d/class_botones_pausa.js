var class_botones_pausa =
[
    [ "botonMenu", "d5/d0d/class_botones_pausa.html#a38387351491a17f1c8a0e055a1743e3e", null ],
    [ "botonReanudar", "d5/d0d/class_botones_pausa.html#a37695df83ab0bc40cb344d4885ff122b", null ],
    [ "botonSalir", "d5/d0d/class_botones_pausa.html#a86f5726b445c84c0c87f3df8dc446dd0", null ],
    [ "tecla1", "d5/d0d/class_botones_pausa.html#a965f93402e4923443c882ec5edd875d1", null ],
    [ "tecla2", "d5/d0d/class_botones_pausa.html#af95cd0f8b4623d59c94f97a6066ca5f5", null ],
    [ "tecla3", "d5/d0d/class_botones_pausa.html#a2b1ce762b7399259d27ecd09e71ca7a2", null ]
];